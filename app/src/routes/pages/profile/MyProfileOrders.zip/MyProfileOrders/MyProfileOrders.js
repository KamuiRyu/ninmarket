import React from "react";
import MyProfileOrdersHeader from "./MyProfileOrdersHeader";
import MyProfileOrdersContent from "./MyProfileOrdersContent";
import { useOutletContext } from "react-router-dom";
import useMyProfileOrders from "./useMyProfileOrders";


export default function MyProfileOrders() {
  const userData = useOutletContext();
  const { t, orderData, languageUser } = useMyProfileOrders(userData);

  return (
    <div className="user-profile-orders">
      <MyProfileOrdersHeader t={t}>
        
      </MyProfileOrdersHeader>
      <MyProfileOrdersContent t={t} orderData={orderData} languageUser={languageUser}></MyProfileOrdersContent>
    </div>
  );
}
