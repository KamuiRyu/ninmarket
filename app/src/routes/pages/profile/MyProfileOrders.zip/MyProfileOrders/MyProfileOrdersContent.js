import React from "react";
import "../../../../assets/styles/pages/Profile/MyProfileOrders/MyProfileOrdersContent/MyProfileOrdersContent.css";
import FormElements from "../../../../components/common/FormElements";
import { Link } from "react-router-dom";

export default function MyProfileOrdersContent({ t, orderData, languageUser }) {
  return (
    <div className="user-profile-orders-container">
      <div className="user-profile-orders-content">
        <div className="user-profile-orders-sell">
          <div className="orders-sell-header">
            <div className="order-type">{t("profile.ordersPage.wts")}</div>
            <div className="orders-actions">
              <FormElements.ButtonForm
                classButton="btnActionActive w-full h-[30px]"
                classTo="mx-2"
                classButtonHover="hover:bg-indigo-600"
                classButtonFocus="focus:outline-none"
                classButtonAnimation="duration-100 ease-in-out"
              >
                {t("profile.ordersPage.activeBtn")}
              </FormElements.ButtonForm>
              <FormElements.ButtonForm
                classButton="btnActionDelete w-full h-[30px]"
                classTo="mx-2"
                classButtonHover="hover:bg-indigo-600"
                classButtonFocus="focus:outline-none"
                classButtonAnimation="duration-100 ease-in-out"
              >
                {t("profile.ordersPage.desactiveBtn")}
              </FormElements.ButtonForm>
            </div>
          </div>
          <div className="orders-sell-content">
            {orderData &&
              orderData["wts"].map((order, index) => (
                <div key={index} className="order-item">
                  <span>{order.type}</span>
                </div>
              ))}
          </div>
        </div>

        <div className="user-profile-orders-buy">
          <div className="orders-buy-header">
            <div className="order-type">{t("profile.ordersPage.wtb")}</div>
            <div className="orders-actions">
              <FormElements.ButtonForm
                classButton="btnActionActive w-full h-[30px]"
                classTo="mx-2"
                classButtonHover="hover:bg-indigo-600"
                classButtonFocus="focus:outline-none"
                classButtonAnimation="duration-100 ease-in-out"
              >
                {t("profile.ordersPage.activeBtn")}
              </FormElements.ButtonForm>
              <FormElements.ButtonForm
                classButton="btnActionDelete w-full h-[30px]"
                classTo="mx-2"
                classButtonHover="hover:bg-indigo-600"
                classButtonFocus="focus:outline-none"
                classButtonAnimation="duration-100 ease-in-out"
              >
                {t("profile.ordersPage.desactiveBtn")}
              </FormElements.ButtonForm>
            </div>
          </div>
          <div className="orders-buy-content">
            {orderData &&
              orderData["wtb"].map((order, index) => (
                <div key={index} className="order-item">
                  <div className="order-item-icon">
                    <Link to={`/items/${order.Item.slug}`}>
                      <img src={order.Item.image_url} alt={order.Item.slug} />
                    </Link>
                    <div className="order-type-marker">WTS</div>
                  </div>
                  <div className="order-item-name">
                    <Link to={`/items/${order.Item.slug}`}>
                      <span>{order.Item.name[languageUser]}</span>
                    </Link>
                  </div>
                  <div className="order-item-price">
                    <div className="ryo-price">
                      <b className="price">
                        {order.price} {t("profile.ordersPage.ryoEach")}
                      </b>
                    </div>
                  </div>
                  <div className="order-item-quantity">
                    <div className="item-quantity">
                      <span>{order.quantity}</span>
                      <i className="bx bxs-collection"></i>
                    </div>
                  </div>
                  <div className="order-item-actions">
                    <div className="order-buttons">
                      <FormElements.ButtonForm
                        classButton="btnActions w-full"
                        classButtonHover="hover:bg-indigo-600"
                        classButtonFocus="focus:outline-none"
                        classButtonAnimation="duration-100 ease-in-out"
                        classTo="mx-1"
                      >
                        <i className='bx bx-check'></i>
                        Sold
                      </FormElements.ButtonForm>
                      <FormElements.ButtonForm
                        classButton="btnActions w-full"
                        classButtonHover="hover:bg-indigo-600"
                        classButtonFocus="focus:outline-none"
                        classButtonAnimation="duration-100 ease-in-out"
                        classTo="mx-1"
                      >
                        <i class="bx bx-edit mr-2"></i> Edit
                      </FormElements.ButtonForm>
                    </div>
                    <div className="order-buttons mt-1">
                      <FormElements.ButtonForm
                        classButton="btnActions w-full"
                        classButtonHover="hover:bg-indigo-600"
                        classButtonFocus="focus:outline-none"
                        classButtonAnimation="duration-100 ease-in-out"
                        classTo="mx-1"
                      >
                        +1
                      </FormElements.ButtonForm>
                      <FormElements.ButtonForm
                        classButton="btnActions w-full"
                        classButtonHover="hover:bg-indigo-600"
                        classButtonFocus="focus:outline-none"
                        classButtonAnimation="duration-100 ease-in-out"
                        classTo="mx-1"
                      >
                        <i className='bx bx-show mr-2'></i> Invisible
                      </FormElements.ButtonForm>
                      <FormElements.ButtonForm
                        classButton="btnActions w-full"
                        classButtonHover="hover:bg-indigo-600"
                        classButtonFocus="focus:outline-none"
                        classButtonAnimation="duration-100 ease-in-out"
                        classTo="mx-1"
                      >
                        <i className='bx bxs-trash'></i>
                      </FormElements.ButtonForm>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
