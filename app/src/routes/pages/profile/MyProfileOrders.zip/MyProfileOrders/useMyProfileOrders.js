import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import axios from "axios";

const useMyProfileOrders = (userData) => {
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(true);
  const [orderData, setOrderData] = useState("");
  const [languageUser, setLanguageUser] = useState(
    localStorage.getItem("language") ? localStorage.getItem("language") : "en"
  );
  useEffect(() => {
    const languageFromLocalStorage = localStorage.getItem("language");
    setLanguageUser(languageFromLocalStorage);
  }, [localStorage.getItem("language")]);


  useEffect(() => {
    const fetchData = async () => {
      try {
        axios.defaults.withCredentials = true;
        const ordersResponse = await axios.get(
          `${process.env.REACT_APP_API_URL}:${process.env.REACT_APP_API_PORT}/api/order/user/`,
          {
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            params: {
              name: userData.user && userData.user.name ? userData.user.name : "",
            },
            withCredentials: true,
            mode: "cors",
          }
        );

        if (ordersResponse.status === 200) {
          setOrderData(ordersResponse.data);
          console.log(ordersResponse.data);
        }
        setIsLoading(true);
      } catch (error) {
        console.error("Erro ao buscar o item ou os pedidos:", error);
        setIsLoading(true);
      }
    };
    fetchData();
  }, [userData]);

  return { t, orderData, languageUser };
};

export default useMyProfileOrders;
